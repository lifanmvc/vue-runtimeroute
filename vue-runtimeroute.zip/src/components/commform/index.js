import Commform from './src/Commform'

/* istanbul ignore next */
Commform.install = function (Vue) {
  Vue.component(Commform.name, Commform)
}

export default Commform
