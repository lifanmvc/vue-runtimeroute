<template>
  <div>
    我是表单
  </div>
</template>

<script>
export default {
  name: 'Commform'
}
</script>

<style lang="scss" scoped></style>
