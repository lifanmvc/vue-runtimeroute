<template>
  <div class="container home">
    <header>
      <el-form label-position="right">
        <el-form-item label="路由名称" label-width="80px">
          <el-input v-model="routeName" placeholder="请输入路由名称"></el-input>
        </el-form-item>
        <el-form-item label="组件路径" label-width="80px">
          <el-input
            v-model="componentUrl"
            placeholder="请输入组件路径"
          ></el-input>
        </el-form-item>

        <el-form-item>
          <el-button @click="handleAddRoute" type="primary">添加路由</el-button>
          <el-button type="primary">跳转路由</el-button>
        </el-form-item>
      </el-form>
    </header>
    <el-divider @click="handleGoRoute" content-position="left"
      >下面是子路由</el-divider
    >
    <section>
      <router-view />
    </section>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'Home',
  data () {
    return {
      routeName: 'newRoute',
      componentUrl: 'components/commform/index.js'
    }
  },
  methods: {
    handleAddRoute () {
      // 获取当前路由
    },
    handleGoRoute () {}
  },
  components: {}
}
</script>

<style lang="scss" scoped>
.home {
  display: flex;
  flex-direction: column;
  padding: 10px;
  > section {
    border: 1px solid green;
    flex: 1;
  }
}
</style>
